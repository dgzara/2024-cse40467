OK_FORMAT = True

test = {   'name': 'q6',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> def test_q6_validity(X):\n...     assert isinstance(X, pd.DataFrame)\n>>> test_q6_validity(X)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
