OK_FORMAT = True

test = {   'name': 'q2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q2_validity(numeric_columns):\n'
                                               '...     assert numeric_columns\n'
                                               '...     assert len(numeric_columns) > 1\n'
                                               '>>> test_q2_validity(numeric_columns)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
