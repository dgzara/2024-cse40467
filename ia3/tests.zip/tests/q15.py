OK_FORMAT = True

test = {   'name': 'q15',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q15_validity(clustering):\n...     assert isinstance(clustering, DBSCAN)\n>>> test_q15_validity(clustering)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
