OK_FORMAT = True

test = {   'name': 'q26',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> def test_q26_validity(tsne):\n...     assert isinstance(tsne, TSNE)\n>>> test_q26_validity(tsne)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
