OK_FORMAT = True

test = {   'name': 'q1',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> def test_q1_validity(df):\n...     assert isinstance(df, pd.DataFrame)\n>>> test_q1_validity(df)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
