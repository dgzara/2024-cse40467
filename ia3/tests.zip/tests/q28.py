OK_FORMAT = True

test = {   'name': 'q28',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q28_validity(df_tsne):\n'
                                               '...     assert isinstance(df_tsne, pd.DataFrame)\n'
                                               "...     assert len(df_tsne['D1']) > 0\n"
                                               "...     assert len(df_tsne['D2']) > 0\n"
                                               '>>> test_q28_validity(df_tsne)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
