OK_FORMAT = True

test = {   'name': 'q24',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> def test_q24_validity(pca):\n...     assert isinstance(pca, PCA)\n>>> test_q24_validity(pca)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
