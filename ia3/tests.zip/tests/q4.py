OK_FORMAT = True

test = {   'name': 'q4',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q4_validity(df, numeric_columns):\n'
                                               '...     for i in numeric_columns:\n'
                                               '...         assert np.mean(df[i]) < 1\n'
                                               '...         assert np.mean(df[i]) > -1\n'
                                               '>>> test_q4_validity(df, numeric_columns)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
