OK_FORMAT = True

test = {   'name': 'q23',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q23_validity(df_pca):\n'
                                               '...     assert isinstance(df_pca, pd.DataFrame)\n'
                                               "...     assert len(df_pca['PCA1']) > 0\n"
                                               "...     assert len(df_pca['PCA2']) > 0\n"
                                               '>>> test_q23_validity(df_pca)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
