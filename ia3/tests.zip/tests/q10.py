OK_FORMAT = True

test = {   'name': 'q10',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> def test_q10_validity(y_kmeans):\n...     assert len(y_kmeans) > 10\n>>> test_q10_validity(y_kmeans)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
