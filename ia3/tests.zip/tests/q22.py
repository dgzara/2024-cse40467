OK_FORMAT = True

test = {   'name': 'q22',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> def test_q22_validity(X_pca):\n...     assert len(X_pca) > 10\n>>> test_q22_validity(X_pca)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
