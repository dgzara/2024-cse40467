OK_FORMAT = True

test = {   'name': 'q16',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> def test_q16_validity(y_dbscan):\n...     assert len(y_dbscan) > 10\n>>> test_q16_validity(y_dbscan)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
