OK_FORMAT = True

test = {   'name': 'q7',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q7_validity(X_simple):\n'
                                               '...     assert isinstance(X_simple, pd.DataFrame)\n'
                                               '...     assert len(X_simple.columns) == 2\n'
                                               "...     assert len(X_simple['in_spotify_playlists'])\n"
                                               "...     assert len(X_simple['in_apple_playlists'])\n"
                                               '>>> test_q7_validity(X_simple)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
