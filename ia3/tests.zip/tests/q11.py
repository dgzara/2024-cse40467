OK_FORMAT = True

test = {   'name': 'q11',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> def test_q11_validity(centroids):\n...     assert len(centroids) > 2\n>>> test_q11_validity(centroids)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
