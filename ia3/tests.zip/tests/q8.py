OK_FORMAT = True

test = {   'name': 'q8',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> def test_q8_validity(kmeans):\n...     assert isinstance(kmeans, KMeans)\n>>> test_q8_validity(kmeans)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
