OK_FORMAT = True

test = {   'name': 'q27',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> def test_q27_validity(X_tsne):\n...     assert len(X_tsne) > 10\n>>> test_q27_validity(X_tsne)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
