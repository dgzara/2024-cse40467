OK_FORMAT = True

test = {   'name': 'q4',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q4_validity(model3, y_binary):\n'
                                               "...     coefficients = ['const', 'work_year', 'remote_ratio', 'company_size_M', 'company_size_L', 'experience_level_MI', 'experience_level_SE', "
                                               "'experience_level_EX', 'job_title_Data Engineer']\n"
                                               '...     assert isinstance(model3, statsmodels.discrete.discrete_model.BinaryResultsWrapper)\n'
                                               '...     assert min(y_binary) >= 0\n'
                                               '...     assert max(y_binary) <= 1\n'
                                               '...     assert len(model3.params) > 0\n'
                                               '...     assert set(coefficients).issubset(set(model2.params.index))\n'
                                               '>>> test_q4_validity(model3, y_binary)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
