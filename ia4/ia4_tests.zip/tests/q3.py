OK_FORMAT = True

test = {   'name': 'q3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q3_validity(model2, y_transformed):\n'
                                               "...     coefficients = ['const', 'work_year', 'remote_ratio', 'company_size_M', 'company_size_L', 'experience_level_MI', 'experience_level_SE', "
                                               "'experience_level_EX', 'job_title_Data Engineer']\n"
                                               '...     assert isinstance(model2, sm.regression.linear_model.RegressionResultsWrapper)\n'
                                               '...     assert np.min(y_transformed) > 80\n'
                                               '...     assert np.max(y_transformed) < 300\n'
                                               '...     assert len(model2.params) > 0\n'
                                               '...     assert set(coefficients).issubset(set(model2.params.index))\n'
                                               '>>> test_q3_validity(model2, y_transformed)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
