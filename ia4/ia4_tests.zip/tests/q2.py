OK_FORMAT = True

test = {   'name': 'q2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q2_validity(model):\n'
                                               "...     coefficients = ['const', 'work_year', 'remote_ratio', 'company_size_M', 'company_size_L', 'experience_level_MI', 'experience_level_SE', "
                                               "'experience_level_EX', 'job_title_Data Engineer']\n"
                                               '...     assert isinstance(model, sm.regression.linear_model.RegressionResultsWrapper)\n'
                                               '...     assert len(model.params) > 0\n'
                                               '...     assert set(coefficients).issubset(set(model.params.index))\n'
                                               '>>> test_q2_validity(model)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
