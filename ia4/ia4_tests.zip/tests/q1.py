OK_FORMAT = True

test = {   'name': 'q1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q1_validity(salaries_df):\n'
                                               "...     columns = ['work_year', 'salary_in_usd', 'remote_ratio', 'company_size_L', 'company_size_M', 'experience_level_EX', 'experience_level_MI', "
                                               "'experience_level_SE', 'job_title_3D Computer Vision Researcher', 'job_title_AI Developer', 'job_title_AI Scientist', 'job_title_Analytics Engineer', "
                                               "'job_title_Applied Data Scientist', 'job_title_Applied Machine Learning Engineer', 'job_title_Applied Machine Learning Scientist', 'job_title_Applied "
                                               "Scientist', 'job_title_BI Analyst', 'job_title_BI Data Analyst', 'job_title_BI Data Engineer', 'job_title_BI Developer', 'job_title_Big Data "
                                               "Engineer', 'job_title_Business Data Analyst', 'job_title_Business Intelligence Engineer', 'job_title_Cloud Data Architect', 'job_title_Cloud Database "
                                               "Engineer', 'job_title_Computer Vision Engineer', 'job_title_Computer Vision Software Engineer', 'job_title_Data Analyst', 'job_title_Data Analytics "
                                               "Consultant', 'job_title_Data Analytics Engineer', 'job_title_Data Analytics Lead', 'job_title_Data Analytics Manager', 'job_title_Data Analytics "
                                               "Specialist', 'job_title_Data Architect', 'job_title_Data Engineer', 'job_title_Data Infrastructure Engineer', 'job_title_Data Lead', 'job_title_Data "
                                               "Manager', 'job_title_Data Modeler', 'job_title_Data Operations Analyst', 'job_title_Data Operations Engineer', 'job_title_Data Quality Analyst', "
                                               "'job_title_Data Science Consultant', 'job_title_Data Science Engineer', 'job_title_Data Science Lead', 'job_title_Data Science Manager', "
                                               "'job_title_Data Science Tech Lead', 'job_title_Data Scientist', 'job_title_Data Scientist Lead', 'job_title_Data Specialist', 'job_title_Deep Learning "
                                               "Engineer', 'job_title_Director of Data Science', 'job_title_ETL Developer', 'job_title_Financial Data Analyst', 'job_title_Head of Data', "
                                               "'job_title_Head of Data Science', 'job_title_Lead Data Analyst', 'job_title_Lead Data Engineer', 'job_title_Lead Data Scientist', 'job_title_ML "
                                               "Engineer', 'job_title_MLOps Engineer', 'job_title_Machine Learning Developer', 'job_title_Machine Learning Engineer', 'job_title_Machine Learning "
                                               "Infrastructure Engineer', 'job_title_Machine Learning Manager', 'job_title_Machine Learning Researcher', 'job_title_Machine Learning Scientist', "
                                               "'job_title_Machine Learning Software Engineer', 'job_title_Manager Data Management', 'job_title_NLP Engineer', 'job_title_Principal Data Analyst', "
                                               "'job_title_Principal Data Engineer', 'job_title_Principal Data Scientist', 'job_title_Principal Machine Learning Engineer', 'job_title_Product Data "
                                               "Analyst', 'job_title_Research Engineer', 'job_title_Research Scientist']\n"
                                               "...     not_columns = ['salary', 'salary_currency', 'company_location', 'employee_residence', 'employment_type']\n"
                                               '...     assert isinstance(salaries_df, pd.DataFrame)\n'
                                               '...     assert salaries_df.isna().sum().sum() == 0\n'
                                               '...     assert salaries_df.remote_ratio.min() >= 0\n'
                                               '...     assert salaries_df.remote_ratio.max() <= 1\n'
                                               '...     assert salaries_df.work_year.min() >= 0\n'
                                               '...     assert salaries_df.work_year.max() <= 1\n'
                                               '...     assert set(columns).issubset(set(salaries_df.columns))\n'
                                               '...     assert not set(not_columns).issubset(set(salaries_df.columns))\n'
                                               '>>> test_q1_validity(salaries_df)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
