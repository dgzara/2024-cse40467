OK_FORMAT = True

test = {   'name': 'q1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q1_validity(df):\n'
                                               "...     columns = ['age', 'workclass', 'fnlwgt', 'education', 'education_num', 'marital_status', 'occupation', 'relationship', 'race', 'capital_gain', "
                                               "'capital_loss', 'hours_per_week', 'native_country', 'income', 'income_over_50k', 'gender_Male']\n"
                                               "...     not_columns = ['sex']\n"
                                               '...     assert isinstance(df, pd.DataFrame)\n'
                                               '...     assert df.age.min() >= -2\n'
                                               '...     assert df.age.max() <= 4\n'
                                               '...     assert df.fnlwgt.min() >= -2\n'
                                               '...     assert df.fnlwgt.max() <= 15\n'
                                               '...     assert set(columns).issubset(set(df.columns))\n'
                                               '...     assert not set(not_columns).issubset(set(df.columns))\n'
                                               '>>> test_q1_validity(census_df)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
