OK_FORMAT = True

test = {   'name': 'q4',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> census_df_matched.isna().sum()\n'
                                               'age                 0\n'
                                               'workclass           0\n'
                                               'fnlwgt              0\n'
                                               'education           0\n'
                                               'education_num       0\n'
                                               'marital_status      0\n'
                                               'occupation          0\n'
                                               'relationship        0\n'
                                               'race                0\n'
                                               'capital_gain        0\n'
                                               'capital_loss        0\n'
                                               'hours_per_week      0\n'
                                               'income              0\n'
                                               'income_over_50k     0\n'
                                               'gender_Male         0\n'
                                               'propensity_score    0\n'
                                               'dtype: int64',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> def test_q4_validity(df):\n'
                                               '...     assert isinstance(df, pd.DataFrame)\n'
                                               '...     assert len(df[df.gender_Male == 0]) == len(df[df.gender_Male == 1])\n'
                                               '...     assert len(df[df.gender_Male == 0]) < 5000\n'
                                               '>>> test_q4_validity(census_df_matched)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
