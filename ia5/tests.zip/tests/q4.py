OK_FORMAT = True

test = {   'name': 'q4',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q4_validity(df):\n'
                                               '...     assert isinstance(df, pd.DataFrame)\n'
                                               '...     assert df.isna().sum().sum() == 0\n'
                                               '...     assert len(df[df.gender_Male == 0]) == len(df[df.gender_Male == 1])\n'
                                               '...     assert len(df[df.gender_Male == 0]) < 5000\n'
                                               '>>> test_q4_validity(census_df_matched)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
