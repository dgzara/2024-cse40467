OK_FORMAT = True

test = {   'name': 'q2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q2_validity(model):\n'
                                               "...     coefficients = ['Intercept', 'gender_Male']\n"
                                               '...     assert isinstance(model, statsmodels.discrete.discrete_model.BinaryResultsWrapper)\n'
                                               '...     assert len(model.params) > 0\n'
                                               '...     assert set(coefficients).issubset(set(model.params.index))\n'
                                               '...     assert round(np.exp(model.params.gender_Male), 2) == 3.58\n'
                                               '>>> test_q2_validity(model_nomatching)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
