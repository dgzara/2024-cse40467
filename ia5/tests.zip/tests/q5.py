OK_FORMAT = True

test = {   'name': 'q5',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q5_validity(model):\n'
                                               "...     coefficients = ['Intercept', 'gender_Male']\n"
                                               '...     assert isinstance(model, statsmodels.discrete.discrete_model.BinaryResultsWrapper)\n'
                                               '...     assert len(model.params) > 0\n'
                                               '...     assert set(coefficients).issubset(set(model.params.index))\n'
                                               '...     assert round(np.exp(model.params.gender_Male), 1) == 2.1\n'
                                               '>>> test_q5_validity(model_matching)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
