OK_FORMAT = True

test = {   'name': 'q3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def test_q3_validity(df, res):\n'
                                               "...     columns = ['age', 'fnlwgt', 'C(education)', 'C(workclass)', 'C(marital_status)', 'C(occupation)', 'C(relationship)', 'C(race)', "
                                               "'capital_gain', 'capital_loss', 'hours_per_week']\n"
                                               '...     assert isinstance(df, pd.DataFrame)\n'
                                               '...     assert isinstance(res, statsmodels.discrete.discrete_model.BinaryResultsWrapper)\n'
                                               "...     assert set(columns).issubset(set(propensity_model.formula.split(' ~ ')[1].split(' + ')))\n"
                                               '...     assert df.propensity_score.min() >= 0\n'
                                               '...     assert df.propensity_score.max() <= 1\n'
                                               '>>> test_q3_validity(census_df, propensity_res)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
